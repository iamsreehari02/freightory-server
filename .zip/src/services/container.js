import User from "../models/User.js";
import { Container } from "../models/Container.js";
import { generateContainerId } from "../utils/generateContainerId.js";
import { logContainerActivity } from "../utils/containerLogUpdater.js";
import { ContainerLog } from "../models/ContainerLog.js";
import { Port } from "../models/Port.js";
import mongoose from "mongoose";

// export const createContainer = async (data, user) => {
//   const containerId = await generateContainerId(user.country);

//   const container = new Container({
//     containerId,
//     country: data.country,
//     port: data.port,
//     unitsAvailable: data.unitsAvailable,
//     availableFrom: data.availableFrom,
//     status: data.status || "available",
//     createdBy: user._id,
//     companyId: user.companyId,
//   });

//   const savedContainer = await container.save();

//   // Include port in log message
//   await logContainerActivity({
//     containerId: savedContainer._id,
//     action: "created",
//     message: `Container ${containerId} created at ${data.port} port`,
//     createdBy: user._id,
//   });

//   return savedContainer;
// };

// export const createContainer = async (data, user) => {
//   let port;

//   // Check if data.port looks like a valid ObjectId (existing port)
//   if (mongoose.Types.ObjectId.isValid(data.port)) {
//     port = await Port.findOne({
//       _id: data.port,
//       companyId: user.companyId,
//     });
//   }

//   // If port not found, treat data.port as a new port name
//   if (!port) {
//     // Create new port with given name and country & companyId from user
//     port = new Port({
//       name: data.port,
//       country: data.country,
//       companyId: user.companyId,
//     });
//     await port.save();
//   }

//   const containerId = await generateContainerId(user.country);

//   const container = new Container({
//     containerId,
//     country: data.country,
//     port: port._id, // store the port reference
//     unitsAvailable: data.unitsAvailable,
//     availableFrom: data.availableFrom,
//     status: data.status || "available",
//     createdBy: user._id,
//     companyId: user.companyId,
//   });

//   const savedContainer = await container.save();

//   // Populate port field
//   await savedContainer.populate("port");

//   await logContainerActivity({
//     containerId: savedContainer._id,
//     action: "created",
//     message: `Container ${containerId} created at ${port.name} port`,
//     createdBy: user._id,
//   });

//   return savedContainer;
// };

export const createContainer = async (data, user, retryCount = 0) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    let port;

    // Check if data.port is ObjectId (existing port)
    if (mongoose.Types.ObjectId.isValid(data.port)) {
      port = await Port.findOne(
        {
          _id: data.port,
          companyId: user.companyId,
        },
        null,
        { session }
      );
    }

    // If port not found, create a new port
    if (!port) {
      port = new Port({
        name: data.port,
        country: data.country,
        companyId: user.companyId,
      });
      await port.save({ session });
    }

    // Generate containerId
    const containerId = await generateContainerId(
      user.companyId,
      data.country,
      session
    );

    // Create container
    const container = new Container({
      containerId,
      country: data.country,
      port: port._id,
      unitsAvailable: data.unitsAvailable,
      availableFrom: data.availableFrom,
      status: data.status || "available",
      createdBy: user._id,
      companyId: user.companyId,
      specialRate: data.specialRate,
      agentDetails: data.agentDetails,
    });

    const savedContainer = await container.save({ session });

    // Populate port after save
    await savedContainer.populate("port");

    // Log activity
    await logContainerActivity(
      {
        companyId: user.companyId,
        containerId: savedContainer._id,
        action: "created",
        message: `Container ${containerId} created at ${port.name} port`,
        createdBy: user._id,
      },
      session
    );

    await session.commitTransaction();
    session.endSession();

    return savedContainer;
  } catch (error) {
    await session.abortTransaction();
    session.endSession();

    if (error.code === 11000 && retryCount < 3) {
      console.log(
        `Duplicate containerId detected. Retrying... Attempt ${retryCount + 1}`
      );
      return createContainer(data, user, retryCount + 1);
    }

    throw error;
  }
};

export const getNextContainerId = async (userId) => {
  const user = await User.findById(userId).populate("company").lean();
  if (!user || user.role !== "nvocc") throw new Error("Unauthorized");

  const country = user.companyId?.country || user.country;
  if (!country) throw new Error("User country not found");

  return await generateContainerId(country);
};

export const updateContainerStatus = async (id, status, companyId) => {
  const container = await Container.findOneAndUpdate(
    { _id: id, companyId },
    {
      $set: { status },
      $push: {
        activityLog: {
          action: status,
          message: `Status updated to ${status}`,
        },
      },
    },
    { new: true, runValidators: true }
  );

  if (!container) {
    throw new Error("Container not found or not authorized");
  }

  return container;
};

// Get container stats
// export const getContainerStats = async () => {
//   const total = await Container.countDocuments();
//   const available = await Container.countDocuments({ status: "available" });
//   const inUse = await Container.countDocuments({ status: "in-use" });
//   const maintenance = await Container.countDocuments({ status: "maintenance" });

//   return { total, available, inUse, maintenance };
// };
export const getAllContainerLogsService = async (companyId = null) => {
  const logs = await ContainerLog.find()
    .populate("createdBy", "name")
    .populate({
      path: "containerId",
      match: companyId ? { companyId } : {},
      select: "containerId port companyId",
      populate: {
        path: "port",
        select: "name country",
      },
    })
    .sort({ createdAt: -1 });

  // If companyId is provided → filter out logs from other companies
  return companyId ? logs.filter((log) => log.containerId) : logs;
};

export const getLatestContainers = async (companyId, skip = 0, limit = 20) => {
  return await Container.find({
    isDeleted: { $ne: true },
    companyId,
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .populate("companyId", "companyName")
    .populate("port", "name country");
};

export const getContainerByIdService = async (id, companyId) => {
  return await Container.findOne({
    _id: id,
    isDeleted: { $ne: true },
    companyId,
  })
    .populate("companyId", "companyName")
    .populate({
      path: "port",
      select: "name country",
    });
};

// export async function softDeleteContainer(id, companyId) {
//   return Container.findOneAndUpdate(
//     { _id: id, companyId },
//     { isDeleted: true, deletedAt: new Date() },
//     { new: true }
//   );
// }

export async function softDeleteContainer(id, companyId, userId) {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    // Soft delete the container
    const container = await Container.findOneAndUpdate(
      { _id: id, companyId },
      { isDeleted: true, deletedAt: new Date() },
      { new: true, session }
    );

    if (!container) {
      throw new Error("Container not found or already deleted");
    }

    // Log the deletion in ContainerLog
    await logContainerActivity(
      {
        companyId,
        containerId: container._id,
        action: "removed",
        message: `Container ${container.containerId} was removed`,
        createdBy: userId,
      },
      session // pass session for transaction
    );

    await session.commitTransaction();
    session.endSession();

    return container;
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    throw error;
  }
}
