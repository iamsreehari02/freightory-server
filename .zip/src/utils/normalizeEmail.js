export function normalizeEmail(email) {
  return email.trim().toLowerCase();
}
