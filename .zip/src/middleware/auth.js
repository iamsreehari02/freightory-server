import { getTokenFromCookie } from "../config/cookie.js";
import { verifyJwt } from "../config/jwt.js";

export const requireAuth = (req, res, next) => {
  const token = getTokenFromCookie(req);
  if (!token) return res.status(401).json({ message: "Unauthorized" });

  const decoded = verifyJwt(token);
  if (!decoded) return res.status(401).json({ message: "Invalid token" });

  req.user = decoded;
  next();
};
